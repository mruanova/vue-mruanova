# mruanova.com
This website is my career portfolio and it implements the following technologies: HTML5 / CSS3 / JavaScript Bootstrap AngularJS / NodeJS Cloud computing AWS (Amazon Web Services) Route 53 / S3 bucket API Gateway Microservices Lambda Functions DynamoDB Web API
